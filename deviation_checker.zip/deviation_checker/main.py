import os
import cv2
import pandas as pd
from utils import extract_features, extract_frames, split_test_video

# Paths
REF_VIDEO = r"C:\Users\91997\Desktop\deviation_checker\ref_satge.mp4"
TEST_VIDEO = "test_stage.mp4"
RESULT_DIR = "results"
CLIPS_DIR = os.path.join(RESULT_DIR, "clips")
os.makedirs(CLIPS_DIR, exist_ok=True)

# Load reference features
ref_frames = extract_frames(REF_VIDEO)
ref_features = [extract_features(ref_frames[i], ref_frames[i+1]) for i in range(len(ref_frames)-1)]

# Segment test video
segments = split_test_video(TEST_VIDEO)

deviation_log = []

for idx, segment_frames in enumerate(segments):
    segment_features = [extract_features(segment_frames[i], segment_frames[i+1])
                        for i in range(len(segment_frames)-1)]

    # Compare average SSIM and hist diff with reference
    avg_ssim = sum(f["ssim"] for f in segment_features) / len(segment_features)
    avg_hist = sum(f["hist_diff"] for f in segment_features) / len(segment_features)
    ref_avg_ssim = sum(f["ssim"] for f in ref_features) / len(ref_features)
    ref_avg_hist = sum(f["hist_diff"] for f in ref_features) / len(ref_features)

    # Threshold based deviation detection
    is_deviation = avg_ssim < (ref_avg_ssim - 0.08) or avg_hist > (ref_avg_hist + 0.2)

    if is_deviation:
        clip_path = os.path.join(CLIPS_DIR, f"deviation_{idx}.mp4")
        height, width = segment_frames[0].shape[:2]
        writer = cv2.VideoWriter(clip_path, cv2.VideoWriter_fourcc(*'mp4v'), 15, (width, height))
        for frame in segment_frames:
            writer.write(frame)
        writer.release()

        deviation_log.append({
            "Segment": idx,
            "SSIM": round(avg_ssim, 4),
            "HistDiff": round(avg_hist, 4),
            "Deviation": True,
            "Clip": clip_path
        })
    else:
        deviation_log.append({
            "Segment": idx,
            "SSIM": round(avg_ssim, 4),
            "HistDiff": round(avg_hist, 4),
            "Deviation": False,
            "Clip": None
        })

# Save log to Excel
log_df = pd.DataFrame(deviation_log)
log_df.to_excel(os.path.join(RESULT_DIR, "logs.xlsx"), index=False)

print("✅ Deviation check complete. Results saved in /results.")