import cv2
import numpy as np
from skimage.metrics import structural_similarity as ssim

def extract_features(frame1, frame2):
    gray1 = cv2.cvtColor(frame1, cv2.COLOR_BGR2GRAY)
    gray2 = cv2.cvtColor(frame2, cv2.COLOR_BGR2GRAY)

    ssim_score, _ = ssim(gray1, gray2, full=True)

    hist1 = cv2.calcHist([gray1], [0], None, [256], [0, 256])
    hist2 = cv2.calcHist([gray2], [0], None, [256], [0, 256])
    hist_score = cv2.compareHist(hist1, hist2, cv2.HISTCMP_BHATTACHARYYA)
    return {"ssim": ssim_score, "hist_diff": hist_score}

def extract_frames(video_path):
    cap = cv2.VideoCapture(video_path)
    
    if not cap.isOpened():
        print(f"❌ Could not open video: {video_path}")
        return []

    frame_count = 0
    frames = []

    while True:
        ret, frame = cap.read()
        if not ret:
            print(f"⚠️ Failed to read frame at count {frame_count}")
            break
        frames.append(frame)
        frame_count += 1

    cap.release()
    print(f"✅ Total frames extracted from {video_path}: {len(frames)}")
    return frames


def split_test_video(video_path, min_contour_area=1500):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"❌ Could not open video: {video_path}")
        return []
    fgbg = cv2.createBackgroundSubtractorMOG2(history=100, varThreshold=50)
    segments = []

    frame_buffer = []
    in_motion = False
    frame_count = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        fgmask = fgbg.apply(frame)
        contours, _ = cv2.findContours(fgmask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        moving = any(cv2.contourArea(c) > min_contour_area for c in contours)

        if moving:
            frame_buffer.append(frame)
            in_motion = True
        elif in_motion and len(frame_buffer) > 10:
            segments.append(frame_buffer)
            frame_buffer = []
            in_motion = False

        frame_count += 1

    cap.release()
    return segments