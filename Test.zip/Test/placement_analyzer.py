import cv2
import pandas as pd
from component_detector import detect_components
from utils import extract_clip
from scipy.spatial.distance import cosine

def vectorize_layout(layout, max_len=30):
    vec = []
    for comp in layout:
        vec.extend([hash(comp[0]) % 100, comp[1], comp[2]])
    return vec[:max_len] + [0] * max(0, max_len - len(vec))

def average_layout(frames):
    """
    Averages component positions over given frames.
    Currently returns layout from last frame only (simplified).
    """
    return frames[-1] if frames else []

def analyze_video_against_reference(ref_path, test_path, roi, feedback, log_file, clip_dir):
    cap_ref = cv2.VideoCapture(ref_path)
    cap_test = cv2.VideoCapture(test_path)
    x, y, w, h = roi
    ref_layouts = []
    test_layouts = []

    # Extract reference component layouts from all frames
    while True:
        ret, frame = cap_ref.read()
        if not ret: break
        roi_frame = frame[y:y+h, x:x+w]
        ref_layouts.append(detect_components(roi_frame))
    cap_ref.release()

    cycle_len = len(ref_layouts)  # assume fixed length

    # Extract test component layouts from all frames
    while True:
        ret, frame = cap_test.read()
        if not ret: break
        roi_frame = frame[y:y+h, x:x+w]
        test_layouts.append(detect_components(roi_frame))
    cap_test.release()

    logs = []
    fps = 25

    for i in range(0, len(test_layouts), cycle_len):
        cycle = test_layouts[i:i+cycle_len]
        if len(cycle) < cycle_len:
            continue

        # 📌 Ignore first few frames (e.g., hand motion), use last 2 frames
        safe_test_frames = cycle[-2:]
        test_avg = average_layout(safe_test_frames)

        # Reference layout: middle of reference cycle
        ref_vec = vectorize_layout(ref_layouts[cycle_len//2])
        test_vec = vectorize_layout(test_avg)

        dist = cosine(ref_vec, test_vec)

        if dist < feedback.threshold:
            feedback.add_normal(cycle)
            continue

        if feedback.is_known_deviation(cycle):
            logs.append({"cycle": i//cycle_len+1, "status": "Known Deviation"})
            continue

        clip_path = f"{clip_dir}/cycle_{i//cycle_len+1}.mp4"
        extract_clip(test_path, i, i+cycle_len, roi, clip_path, fps)
        logs.append({"cycle": i//cycle_len+1, "status": "Deviation", "clip": clip_path})
        feedback.add_deviation(cycle)

    df = pd.DataFrame(logs)
    df.to_excel(log_file, index=False)
