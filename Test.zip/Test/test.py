import cv2
import numpy as np

def draw_board(frame, cx, cy, color_bgr, label):
    cv2.circle(frame, (cx, cy), 10, color_bgr, -1)
    cv2.putText(frame, label, (cx - 10, cy - 15), cv2.FONT_HERSHEY_SIMPLEX, 0.4, color_bgr, 1)

def generate_reference_video(path="reference_videos/board1_ref.mp4", fps=10):
    w, h = 400, 300
    board = np.ones((h, w, 3), dtype=np.uint8) * 255
    frames = []

    for _ in range(15):  # static board
        frame = board.copy()
        # Place 1 black
        draw_board(frame, 100, 150, (0, 0, 0), "B")
        # Place 1 white
        draw_board(frame, 150, 150, (255, 255, 255), "W")
        # 2 copper
        draw_board(frame, 200, 150, (0, 140, 255), "C1")  # Orange-ish
        draw_board(frame, 250, 150, (0, 140, 255), "C2")
        frames.append(frame)

    out = cv2.VideoWriter(path, cv2.VideoWriter_fourcc(*'mp4v'), fps, (w, h))
    for f in frames: out.write(f)
    out.release()
    print(f"✅ Reference video saved: {path}")

generate_reference_video()
