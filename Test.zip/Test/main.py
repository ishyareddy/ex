import os
from utils import select_roi, extract_clip
from placement_analyzer import analyze_video_against_reference
from feedback_manager import FeedbackManager

BOARD = "board1"
REF_VIDEO = f"reference_videos/{BOARD}_ref.mp4"
TEST_VIDEO = f"test_videos/{BOARD}_test.mp4"
MEMORY_FILE = f"memory/{BOARD}_memory.json"
LOG_FILE = f"logs/{BOARD}_log.xlsx"
CLIP_DIR = "clips"

def main():
    os.makedirs("logs", exist_ok=True)
    os.makedirs("clips", exist_ok=True)
    os.makedirs("memory", exist_ok=True)

    print("Select ROI (board area)...")
    roi = select_roi(TEST_VIDEO)

    feedback = FeedbackManager(MEMORY_FILE)
    analyze_video_against_reference(
        REF_VIDEO, TEST_VIDEO, roi, feedback, LOG_FILE, CLIP_DIR
    )
    feedback.save_memory()

if __name__ == "__main__":
    main()
