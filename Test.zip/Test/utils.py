import cv2

def select_roi(video_path):
    cap = cv2.VideoCapture(video_path)
    ret, frame = cap.read()
    if not ret:
        raise Exception("Failed to read video.")
    roi = cv2.selectROI("Select ROI", frame)
    cv2.destroyAllWindows()
    cap.release()
    return roi

def extract_clip(video_path, start_frame, end_frame, roi, output_path, fps):
    cap = cv2.VideoCapture(video_path)
    x, y, w, h = roi
    cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_path, fourcc, fps, (w, h))
    for _ in range(end_frame - start_frame):
        ret, frame = cap.read()
        if not ret: break
        out.write(frame[y:y+h, x:x+w])
    cap.release()
    out.release()
