import json
import numpy as np
from scipy.spatial.distance import cosine

class FeedbackManager:
    def __init__(self, path):
        self.path = path
        self.memory = {"normal": [], "deviation": []}
        self.threshold = 0.3
        self.load_memory()

    def save_memory(self):
        with open(self.path, 'w') as f:
            json.dump(self.memory, f)

    def load_memory(self):
        try:
            with open(self.path, 'r') as f:
                self.memory = json.load(f)
        except:
            pass

    def vectorize(self, cycle, max_len=300):
        vec = []
        for step in cycle:
            for comp in step:
                vec.extend([hash(comp[0]) % 100, comp[1], comp[2]])
        return vec[:max_len] + [0] * max(0, max_len - len(vec))

    def is_known_deviation(self, cycle):
        test_vec = self.vectorize(cycle)
        for v in self.memory["deviation"]:
            if cosine(test_vec, v) < self.threshold:
                return True
        return False

    def add_normal(self, cycle):
        v = self.vectorize(cycle)
        self.memory["normal"].append(v)

    def add_deviation(self, cycle):
        v = self.vectorize(cycle)
        self.memory["deviation"].append(v)
