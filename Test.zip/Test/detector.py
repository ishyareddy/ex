import cv2

def detect_components(frame):
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    masks = {
        "R": ((0, 100, 100), (10, 255, 255)),       # Red
        "G": ((40, 50, 50), (80, 255, 255)),        # Green
        "B": ((100, 50, 50), (130, 255, 255)),      # Blue
    }

    result = []
    for label, (low, high) in masks.items():
        mask = cv2.inRange(hsv, low, high)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for cnt in contours:
            M = cv2.moments(cnt)
            if M["m00"] == 0: continue
            cx = int(M["m10"] / M["m00"])
            cy = int(M["m01"] / M["m00"])
            result.append((label, cx, cy))

    result.sort()
    return result
